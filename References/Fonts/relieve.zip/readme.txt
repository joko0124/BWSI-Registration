Note : This demo font is for PERSONAL USE ONLY!
But any donation are very appreciated.

Paypal account for donation https://paypal.me/makeitproject

Please visit our store for more great fonts :
https://creativemarket.com/Godzillab

And follow my instagram for update :@godzillabstudio

Thankyou